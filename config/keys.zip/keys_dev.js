module.exports = {
    mongoURI:
    "mongodb+srv://slack:YIzBxuMTeFSK5sxS@cluster0-wbklx.mongodb.net/test?retryWrites=true&w=majority",
    secretOrKey: 'secret'
    }; 